#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <fog.glsl>
uniform sampler2D Sampler0;uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;in vec4 vertexColor;in vec2 texCoord0;flat in float bT;flat in float bX;in vec2 bU;in vec2 bW;flat in vec4 bZ;out vec4 fragColor;void main(){vec4 texColor=texture(Sampler0,texCoord0).rrrr;vec4 color=texColor*vertexColor*ColorModulator;if(color.a<0.1)discard;if(bX>0.5){if(bT<-0.5&&(bW.x<bZ.x||bW.x>bZ.y||bW.y<bZ.z||bW.y>bZ.w))discard;fragColor=color;}else{fragColor=linear_fog(color,vertexDistance,FogStart,FogEnd,FogColor);}}
