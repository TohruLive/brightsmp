#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec4 vertexColor;out vec2 texCoord0;flat out float bT;flat out float bX;out vec2 bU;out vec2 bW;flat out vec4 bZ;const float bO=110.0;const float ag=3.5;const float az=ag*tan(radians(bO*0.5));const float Y=0.05;const float ai=2.0;const float bS=0.004;uniform sampler2D Sampler0;
#moj_import <minecraft:globals.glsl>
#define W GameTime
#define aj 8704.0
#define T 32
#define U 31
#define bo 4
#define br 3145728
#define bs 6656
#define bt -0.500000000
#define bu 0.000262960180
#define bF 16384.0
#define bD 2072576.0
#define bB 8192.0
#define bE 251
#define bA 254
#define bG 512
#define bC 249
#define bK 0.100000000
#define bJ 0.0149586227
#define bL -0.0500000000
#define bM -0.100000000
#define bN 0.000293040293
#define bH 0.00140625000
#define bI 0.00250000000
#define bw 3.00000000
#define bv 19.0000000
#define ah 182
#define bm 1024
#define bn -0.500000000
#define aX 2097152
#define aR 2883584
#define aS 512
#define aT 48
#define bc 32
#define bd 8
#define be 4
#define aW 16
#define bg 2
#define bh 4
#define bi 5
#define bj 6
#define aQ 8
#define bl -0.750000000
#define aU 0.0000610550309
#define aV 0.000122100122
#define aY 253
#define aZ 0.500000000
#define bb 0.00793650794
#define n 1.77777778
#define aO 3
#define aD 9
#define aF 256.000000
#define aK 240
#define aL 4096.00000
#define aM 2048.00000
#define aN 0.500000000
#define aI 3328.00000
#define aJ 0.500000000
#ifndef W
#define W 0.0
#endif
#define J 6000.00000
#define F 1000.00000
#define av 2884608
#define ap 7078912
#define am 4194304
#define au 4095.00000
#define ar 255
#define ax 0.500000000
#define aq 32.0000000
#define aw 16.0000000
#define ao 0.500000000
#define ay 8.00000000
#define as 2.00000000
#define at 1.25000000
#define ak 64
#define aE 1
#define I 4
#define N 8
#define O 16
#define H 511.000000
#define G 128
#define aG 2
#define aH 8
#define h 8.00000000
#define af 6
#define ad 250
#define ac 2
#define aa 12
#define ab 16
#define l 4
#define f 20.0000000
#define k 1
#define aP 4
#define bQ 200
#define ae 2
#define B 201
#define C 39
#define D 19968
#define aA 0
#define aB 1
#define Q 17.777778
#define P 10.000000
#define V 0.2000592966
void cf(int g,float fx,float fy){
#if aA || aB
bX=1.0;bT=aA!=0?float(g):0.0;bW=vec2((fx-0.5)*Q,(0.5-fy)*P)*V;
#endif
}void cO(vec4 r,float fx,float fy){
#if aB
bX=1.0;bT=-1.0;bW=vec2((fx-0.5)*Q,(0.5-fy)*P)*V;bZ=vec4((r.x-0.5)*Q,(r.z-0.5)*Q,(0.5-r.w)*P,(0.5-r.y)*P)*V;
#endif
}int cA(ivec2 c,int dir,int j){vec3 t=texelFetch(Sampler0,c+ivec2(dir*(j/3),0),0).rgb;int m=j-(j/3)*3;float v=m==0?t.r:(m==1?t.g:t.b);return int(v*255.0+0.5);}float cB(ivec2 c,int dir,int o){int u=cA(c,dir,o)+cA(c,dir,o+1)*256+cA(c,dir,o+2)*65536;if(u>=8388608)u-=16777216;return float(u)/65536.0;}vec4 cC(ivec2 c,int dir,int o){return vec4(cB(c,dir,o),cB(c,dir,o+3),cB(c,dir,o+6),cB(c,dir,o+9));}float cz(ivec2 c,int dir,int o){return cB(c,dir,o)*(65536.0/aF);}vec2 ca(int a,float gw,float gh){return vec2(float(a-(a/3)*3)*0.5*gw,float(a/3)*0.5*gh);}int ci(int i){int t=i/3;int row=t/ad;vec3 v=texelFetch(Sampler0,ivec2(af+t-row*ad,row),0).rgb;int c=i-t*3;return int((c==0?v.r:(c==1?v.g:v.b))*255.0+0.5);}int cm(int i){return ci(i)*256+ci(i+1);}int cn(int i){return ci(i)*65536+ci(i+1)*256+ci(i+2);}float ck(int i){int u=cm(i);return float(u>=32768?u-65536:u);}float cl(int i){int u=cn(i);return float(u>=8388608?u-16777216:u);}bool ch(int kind){ivec2 s=textureSize(Sampler0,0);if(s.x<af+ad)return false;vec3 a=texelFetch(Sampler0,ivec2(af,0),0).rgb*255.0;vec3 b=texelFetch(Sampler0,ivec2(af+1,0),0).rgb*255.0;vec3 c=texelFetch(Sampler0,ivec2(af+2,0),0).rgb*255.0;vec3 d=texelFetch(Sampler0,ivec2(af+3,0),0).rgb*255.0;return all(lessThan(abs(a-vec3(78.0,88.0,50.0)),vec3(0.5)))&&all(lessThan(abs(b-vec3(167.0,28.0,227.0)),vec3(0.5)))&&all(lessThan(abs(c-vec3(91.0,150.0,45.0)),vec3(0.5)))&&abs(d.r-float(ac))<0.5&&abs(d.g-float(kind))<0.5;}vec4 co(int i){int o=aa+(i-1)*12;return vec4(cl(o),cl(o+3),cl(o+6),cl(o+9))/65536.0;}float cp(int e,float u){if(e==1)return u*u;if(e==2)return u*(2.0-u);if(e==3)return u*u*(3.0-2.0*u);if(e==4){float w=u-1.0;return 1.0+2.70158*w*w*w+1.70158*w*w;}if(e==5){if(u<1.0/2.75)return 7.5625*u*u;if(u<2.0/2.75){float v1=u-1.5/2.75;return 7.5625*v1*v1+0.75;}if(u<2.5/2.75){float v2=u-2.25/2.75;return 7.5625*v2*v2+0.9375;}float v3=u-2.625/2.75;return 7.5625*v3*v3+0.984375;}if(e==6)return u<=0.0?0.0:(u>=1.0?1.0:exp2(-10.0*u)*sin((u*10.0-0.75)*2.0943951)+1.0);if(e==7)return u>=1.0?1.0:floor(u*4.0)/4.0;if(e==8)return 0.0;return u;}void cb(int a,float t,out vec2 mv,out float sc,out float rt,out float al){mv=vec2(0.0);sc=1.0;rt=0.0;al=1.0;int mask=ci(a+4);int o=a+5;float tt=t*16.0;for(int i=0;i<5;i++){if((mask&(1<<i))==0)continue;int K=cm(o);int lo=0;int hi=K-1;for(int j=0;j<12;j++){if(lo>=hi)break;int mid=(lo+hi+1)/2;if(float(cn(o+2+mid*6))<=tt)lo=mid;else hi=mid-1;}int ka=o+2+lo*6;int kb=lo+1<K?ka+6:ka;float ta=float(cn(ka));float v=ck(ka+3);if(kb!=ka&&tt>ta)v+=(ck(kb+3)-v)*cp(ci(ka+5),clamp((tt-ta)/(float(cn(kb))-ta),0.0,1.0));if(i==0)mv.x=v/8.0;else if(i==1)mv.y=v/8.0;else if(i==2)sc=v/1000.0;else if(i==3)rt=v/4.0;else al=v/10000.0;o+=2+K*6;}}void ce(inout vec2 q,inout float alpha,int c0,int c1,int n0,int n1){int base=aa+(ci(10)==1?ab:0);int nl=ci(11);float clk=W*24000.0;for(int i=0;i<l;i++){if(i>=nl)break;int b=cn(base+3*i);int S=ci(b);int la=cn(b+12);int L=la>0?cm(la):0;int M=S>0?cm(b+2):1;int dig=-1;if(S>0){int rad=S*M+(L>0?L:S+1);if(n0>0){dig=c0-(c0/rad)*rad;c0=c0/rad;n0-=1;}else if(n1>0){dig=c1-(c1/rad)*rad;c1=c1/rad;n1-=1;}}int an=0;float t=0.0;if(dig>=0&&dig<S*M){int s=dig/M;float e=mod(clk-float(dig-s*M),float(M));if(e>float(M)-f)e=0.0;int sa=cn(b+15+3*s);float len=float(cm(sa));if(e<len||L==0||(ci(sa+3)&k)!=0){an=sa;t=min(e,len);}else{an=la;t=mod(e-len,float(L));}}else if(dig>=0){int r=dig-S*M;if(L>0){an=la;t=mod(clk-float(r),float(L));}else if(r>0){an=cn(b+15+3*(r-1));t=float(cm(an));}}else if(L>0){an=la;t=mod(clk,float(L));}if(an==0)continue;vec2 mv;float sc;float rt;float al;cb(an,t,mv,sc,rt,al);int pv=ci(an+2);vec4 bx=vec4(ck(b+4),ck(b+6),ck(b+8),ck(b+10))/8.0;vec2 pp=vec2(bx.x+float(pv-(pv/3)*3)*0.5*(bx.z-bx.x),bx.y+float(pv/3)*0.5*(bx.w-bx.y));vec2 v=(q-pp)*sc;float rr=radians(rt);q=pp+vec2(v.x*cos(rr)-v.y*sin(rr),v.x*sin(rr)+v.y*cos(rr))+mv;alpha*=al;}}bool cj(vec3 cM,vec4 cL,mat4 cy,mat4 cx,vec2 cN,out vec4 nxColor,inout vec2 cK){nxColor=cL;if(cx[3][3]<0.5)return false;vec3 cq=(cy*vec4(cM,1.0)).xyz;float cF=abs(2.0/cx[0][0]);float cE=abs(2.0/cx[1][1]);float ct=cq.x-cF*0.5-aj;bool cw=ct>0.0?(ct>=bF&&ct<bD):(-ct>bF&&-ct<=bD);bool cv=ct<=-float(aX)&&ct>-float(aR);bool cu=ct<-float(aR)&&ct>=-float(ap);if(!cw&&!cv&&!cu&&ct<float(aX))return false;float cD=cF/max(cE,1.0e-3);float cH,cG;if(cD>n){cG=cE;cH=cE*n;}else{cH=cF;cG=cF/n;}float cI=(cF-cH)*0.5;float cJ=(cE-cG)*0.5;vec2 cg=fract(cN*vec2(textureSize(Sampler0,0)));float cd=cg.x>0.5?1.0:0.0;float cc=cg.y>0.5?1.0:0.0;float cs=floor(cF+0.5);float cr=floor(cE+0.5);if(cw){int ta=int(cL.a*255.0+0.5);if(ta>=255){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}if(ta<1||ta>bA)return false;float tside=ct>0.0?1.0:-1.0;int tfield=tside>0.0?int(floor((ct-bF)/bB)):int(ceil((-ct-bF)/bB))-1;if(tfield<0||tfield>=bE)return false;float tbase=tside>0.0?bF+float(tfield)*bB:-(bF+float(tfield+1)*bB);int tlook=(ta-1)*2*bE+(tside>0.0?tfield:tfield+bE);int tclip=tlook/bG;if(tclip>=bC)return false;int tucode=tlook-tclip*bG;int t8r=int(cL.r*255.0+0.5),t8g=int(cL.g*255.0+0.5),t8b=int(cL.b*255.0+0.5);int ty12=t8r*16+(t8g>>4);float tu=bK*exp2(float(tucode)*bJ);ivec2 tts=textureSize(Sampler0,0);vec4 tbk=texelFetch(Sampler0,ivec2(floor(cN*vec2(tts))),0);bool tbaked=tbk.a>0.99&&int(tbk.r*255.0+0.5)==ah;float tso=tbaked?1.0:(fract(cq.y)>0.25?0.5:1.0);float tlocal;if(tbaked){float btop=float(int(tbk.g*255.0+0.5)),bcell=float(int(tbk.b*255.0+0.5));tlocal=cc>0.5?bcell-btop:-btop;}else{float tyy=cq.y-tso-bw;tlocal=tyy-bv*floor((tyy+6.0)/bv);}nxColor=vec4(float(t8g&15)*17.0,float(t8b>>4)*17.0,float(t8b&15)*17.0,255.0)/255.0;if(tbaked)cK=cN+vec2(0.0,(cc>0.5?-1.0:1.0)/float(tts.y));if(tclip>=B&&tclip<B+C){if(!ch(1)){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int tcode=(ty12&127)*D+tlook-B*bG;int tln=ty12>>7;int teu=tbaked?cm(aa+1):cm(aa+3);float teuf=bK*exp2(float(teu)*bJ);float ttop=ck(aa+5)/8.0+(float(tln-15)*float(cm(aa+9))-float(cm(aa+7)))/32.0;vec2 tq=vec2((ct-tbase-tso-aL)*teuf,ttop+tlocal*teuf);float tal=1.0;ce(tq,tal,tcode,0,ci(aa+11),0);gl_Position=cx*vec4(ca(ci(aa),cs,cr)+tq,cq.z,1.0);nxColor.a*=tal;cf(0,0.5,0.5);return true;}if(tclip>=aK&&ch(1)){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}if(tclip>=aK){vec2 tanc=ca(tclip-aK,cs,cr);gl_Position=cx*vec4(tanc.x+(ct-tbase-tso-aL)*tu,tanc.y+(float(ty12)-aM)*aN+tlocal*tu,cq.z,1.0);cf(0,0.5,0.5);return true;}float tfx=bL+(ct-tbase-tso)*tu*bH;float tfy=bM+float(ty12)*bN+tlocal*tu*bI;gl_Position=cx*vec4(cI+tfx*cH,cJ+tfy*cG,cq.z,1.0);if(tclip>0&&tclip<=bQ){if(ch(ae))cO(co(tclip),tfx,tfy);else cf(0,tfx,tfy);return true;}cf(tclip,tfx,tfy);return true;}if(cu){ivec2 gts=textureSize(Sampler0,0);ivec2 gpc=ivec2(floor(cN*vec2(gts)));int gdir=cd>0.5?-1:1;int gflags=cA(gpc,gdir,0);if((gflags>>4)!=bg||(gflags&bo)!=0||(gflags&aQ)==0)return false;int ga=int(cL.a*255.0+0.5);if(ga<1||ga>ak){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int gw=cA(gpc,gdir,14)+cA(gpc,gdir,15)*256;int gcode=-(int(floor(ct+0.5))-(cd>0.5?gw:0)-1)-av;if(gcode<0||gcode>=am){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int gk=gcode/4096;int gv=(ga-1)*16777216+int(cL.r*255.0+0.5)*65536+int(cL.g*255.0+0.5)*256+int(cL.b*255.0+0.5);int gm=gv/4096;int gqn=2*ar+1;vec2 gq=vec2(float(gk/2-ar),float(gm-(gm/gqn)*gqn-ar))/float(ar);float ge=mod(W*24000.0-float(gm/gqn)/aw,aq);if(ge>=aq-ay)ge-=aq;ge=clamp(ge,-ao,(gk-(gk/2)*2)!=0?as:at);vec2 gp=clamp(vec2(float(gcode-gk*4096),float(gv-gm*4096))/au+sign(gq)*gq*gq*ax*ge,0.0,1.0);vec4 grc=cC(gpc,gdir,2);float gfx=gp.x+(cd>0.5?grc.z:grc.x);float gfy=gp.y+(cc>0.5?grc.w:grc.y);cK=cN+vec2(0.0,(cc>0.5?-1.0:1.0)/float(gts.y));gl_Position=cx*vec4(cI+gfx*cH,cJ+gfy*cG,cq.z,1.0);float gnear=(cx[2][2]>0.0)?1.0:-1.0;gl_Position.z=gl_Position.w*gnear*0.9999;cf(0,0.5,0.5);nxColor=vec4(1.0);return true;}if(ct>=float(br)){ivec2 rts=textureSize(Sampler0,0);ivec2 rc=ivec2(floor(cN*vec2(rts)));int rdir=cd>0.5?-1:1;int rflags=cA(rc,rdir,0);bool rovl=(rflags>>4)==aO;if((!rovl&&(rflags>>4)!=bg)||(rflags&bo)==0)return false;int rclip=cA(rc,rdir,1);int rgrid=cA(rc,rdir,2);int rrow=cA(rc,rdir,3);if(rgrid<1||rrow>=rgrid||(rovl&&rclip>=aD))return false;float rx0=cB(rc,rdir,4),rx1=cB(rc,rdir,7),rh=cB(rc,rdir,10);int rraw=int(floor(ct+0.5))-(cd>0.5?U:0)-br;if(rraw<0)return false;int ridx=rraw/T;int rlevel=ridx/rgrid;if(rlevel>=bs)return false;int rcol=ridx-rlevel*rgrid;cK=cN+vec2(0.0,(cc>0.5?-1.0:1.0)/float(rts.y));nxColor=cL;if(rovl){float rk=65536.0/aF;vec2 ranc=ca(rclip,cs,cr);gl_Position=cx*vec4(ranc.x+(rx0+(float(rcol)+cd)*(rx1-rx0)/float(rgrid))*rk,ranc.y+(float(rlevel)-aI)*aJ+(float(rrow)+cc)*rh*rk/float(rgrid),cq.z,1.0);cf(0,0.5,0.5);return true;}float rfx=rx0+(float(rcol)+cd)*(rx1-rx0)/float(rgrid);float rfy=bt+float(rlevel)*bu+(float(rrow)+cc)*rh/float(rgrid);gl_Position=cx*vec4(cI+rfx*cH,cJ+rfy*cG,cq.z,1.0);if(rclip>0&&rclip<=bQ){if(ch(ae))cO(co(rclip),rfx,rfy);else cf(0,rfx,rfy);return true;}cf(rclip,rfx,rfy);return true;}if(ct<float(aR)){int pq;float pscale=1.0;if(cv){int pa=int(cL.a*255.0+0.5);if(pa<1||pa>aY){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}pscale=aZ*exp2(float(pa-1)*bb);pq=int(ceil((-ct-float(aX))/float(aS)))-1;}else{int praw=int(floor(ct+0.5))-aX;pq=praw/aS;}int pfield=pq/bc;int psub=pq-pfield*bc;if(pfield>=aT)return false;ivec2 pts=textureSize(Sampler0,0);ivec2 pc=ivec2(floor(cN*vec2(pts)));int pdir=cd>0.5?-1:1;int pflags=cA(pc,pdir,0);bool povl=(pflags>>4)==aO&&(pflags&bo)==0&&!cv;int pver=pflags>>4;bool pgif=pver==bh||pver==bj;bool pwin=pver==bi||pver==bj;if(!povl&&((pver!=bg&&!pgif&&!pwin)||(pflags&bo)!=0))return false;if(povl&&(pflags&aE)!=0){int ba=int(cL.a*255.0+0.5);if(ba<1||ba>G){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int ban=cA(pc,pdir,1);if(ban>=aD)return false;int bp=(ba-1)*16777216+int(cL.r*255.0+0.5)*65536+int(cL.g*255.0+0.5)*256+int(cL.b*255.0+0.5);float bto=float(bp-(bp/512)*512);float bfrom=float(bp/512-(bp/262144)*512);float bt0=float(bp/262144);int bbits=cA(pc,pdir,14);float bdelay=(bbits&O)!=0?float(cA(pc,pdir,16)):0.0;float bel=mod(W*24000.0-bt0+J,J);if(bel>J-F)bel=0.0;float bk=clamp((bel-bdelay)/max(float(cA(pc,pdir,15)),1.0),0.0,1.0);bk=bk*bk*(3.0-2.0*bk);if(bt0>=J)bk=1.0;float bf=mix(bfrom,bto,bk)/H;float bx0=cz(pc,pdir,2),by0=cz(pc,pdir,5);float bx1=cz(pc,pdir,8),by1=cz(pc,pdir,11);float btw=float(cA(pc,pdir,17)+cA(pc,pdir,18)*256);float bth=float(cA(pc,pdir,19)+cA(pc,pdir,20)*256);int bdir=bbits-(bbits/4)*4;bool bcrop=(bbits&I)==0;cK=cN+vec2(0.0,(cc>0.5?-1.0:1.0)/float(pts.y));float bcu=(1.0-bf)*btw/float(pts.x),bcv=(1.0-bf)*bth/float(pts.y);if(bdir==0&&cd>0.5){bx1=bx0+bf*(bx1-bx0);if(bcrop)cK.x-=bcu;}if(bdir==1&&cd<0.5){bx0=bx1-bf*(bx1-bx0);if(bcrop)cK.x+=bcu;}if(bdir==2&&cc<0.5){by0=by1-bf*(by1-by0);if(bcrop)cK.y+=bcv;}if(bdir==3&&cc>0.5){by1=by0+bf*(by1-by0);if(bcrop)cK.y-=bcv;}vec2 banc=ca(ban,cs,cr);vec2 bq=vec2(cd>0.5?bx1:bx0,cc>0.5?by1:by0);float bal=1.0;if((pflags&aG)!=0&&ch(0)){int btl=(bbits&N)!=0?30:21;int bcode=(int(floor(ct+0.5))-(cd>0.5?cA(pc,pdir,btl+2)+cA(pc,pdir,btl+3)*256:0)-aX)/aP;ce(bq,bal,0,bcode,0,cA(pc,pdir,btl+1));}gl_Position=cx*vec4(banc+bq,cq.z,1.0);nxColor=vec4(1.0,1.0,1.0,bal);if((bbits&N)!=0){vec3 blo=vec3(float(cA(pc,pdir,21)),float(cA(pc,pdir,22)),float(cA(pc,pdir,23)))/255.0;vec3 bmi=vec3(float(cA(pc,pdir,24)),float(cA(pc,pdir,25)),float(cA(pc,pdir,26)))/255.0;vec3 bhi=vec3(float(cA(pc,pdir,27)),float(cA(pc,pdir,28)),float(cA(pc,pdir,29)))/255.0;nxColor.rgb=bf<0.5?mix(blo,bmi,bf*2.0):mix(bmi,bhi,bf*2.0-1.0);}cf(0,0.5,0.5);return true;}int p8r=int(cL.r*255.0+0.5),p8g=int(cL.g*255.0+0.5),p8b=int(cL.b*255.0+0.5);int px12=p8r*16+(p8g>>4);if(px12<bm){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}cK=cN+vec2(0.0,(cc>0.5?-1.0:1.0)/float(pts.y));if(povl){int pa9=cA(pc,pdir,1);if(pa9>=aD)return false;vec2 panc=ca(pa9,cs,cr);vec2 pq=vec2(cz(pc,pdir,cd>0.5?8:2),cz(pc,pdir,cc>0.5?11:5));float pal=1.0;int ptl=14+((pflags&aG)!=0?4:0);if((pflags&aH)!=0){float pcy=max(float(cA(pc,pdir,ptl)+cA(pc,pdir,ptl+1)*256),1.0)/h;float ptc=mod(W*24000.0,pcy);if(ptc<float(cA(pc,pdir,ptl+2)+cA(pc,pdir,ptl+3)*256)/h||ptc>=float(cA(pc,pdir,ptl+4)+cA(pc,pdir,ptl+5)*256)/h){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}}if((pflags&aG)!=0&&ch(0)){int pcode=(int(floor(ct+0.5))-(cd>0.5?cA(pc,pdir,16)+cA(pc,pdir,17)*256:0)-aX)/aP;ce(pq,pal,(p8r-64)*65536+p8g*256+p8b,pcode,cA(pc,pdir,14),cA(pc,pdir,15));}gl_Position=cx*vec4(panc+pq,cq.z,1.0);cf(0,0.5,0.5);nxColor=vec4(1.0,1.0,1.0,pal);return true;}int psx=psub-(psub/bd)*bd;int psy=psub/bd;float pox=bn+float((px12-bm)*bd+psx)*aU;float poy=bl+float(((p8g&15)*256+p8b)*be+psy)*aV;int pclip=cA(pc,pdir,1);bool hasH=(pflags&1)!=0,hasC=(pflags&2)!=0;if(pgif){int pgt=2+12*(1+(hasH?1:0)+(hasC?1:0))+(pwin?12:0);float pgcy=max(float(cA(pc,pdir,pgt)+cA(pc,pdir,pgt+1)*256),1.0)/h;float pgtc=mod(W*24000.0,pgcy);if(pgtc<float(cA(pc,pdir,pgt+2)+cA(pc,pdir,pgt+3)*256)/h||pgtc>=float(cA(pc,pdir,pgt+4)+cA(pc,pdir,pgt+5)*256)/h){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}}vec4 r=cC(pc,pdir,2);int pstate=pfield/aW;float pk=pstate==0?0.0:float(pfield-pstate*aW)/float(aW-1);if(pstate==1&&hasH)r=mix(r,cC(pc,pdir,14),pk);else if(pstate==2&&hasC)r=mix(hasH?cC(pc,pdir,14):r,cC(pc,pdir,hasH?26:14),pk);else if(pstate==2&&hasH)r=cC(pc,pdir,14);float pfx=pox+pscale*(cd>0.5?r.z:r.x);float pfy=poy+pscale*(cc>0.5?r.w:r.y);gl_Position=cx*vec4(cI+pfx*cH,cJ+pfy*cG,cq.z,1.0);if((pflags&aQ)!=0){float cnear=(cx[2][2]>0.0)?1.0:-1.0;gl_Position.z=gl_Position.w*cnear*0.9999;cf(0,0.5,0.5);}else if(pwin){cO(cC(pc,pdir,2+12*(1+(hasH?1:0)+(hasC?1:0))),pfx,pfy);}else{cf(pclip,pfx,pfy);}nxColor=vec4(1.0,1.0,1.0,cv?1.0:cL.a);return true;}return false;}void main(){vec3 p=Position;bool isNxGui=(ProjMat[2][3]!=0.0)&&(Color.a*255.0>252.4)&&(Color.a*255.0<254.6);bool nxCursor=isNxGui&&(Color.a*255.0<253.6);if(isNxGui){vertexColor=Color;}else{vertexColor=Color*texelFetch(Sampler2,UV2/16,0);}texCoord0=UV0;if(isNxGui){sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;bX=1.0;bT=clamp((15.0-float(UV2.x/16))*16.0+(15.0-float(UV2.y/16)),0.0,255.0);vec4 v=ModelViewMat*vec4(p,1.0);float depth=-v.z;if(nxCursor){bT=0.0;if(abs(depth-float((UV2.x/16)*16+(UV2.y/16))*0.05)<0.15){gl_Position=vec4(0.0,0.0,2.0,1.0);bU=vec2(0.0);bW=vec2(0.0);return;}}if(depth<Y){gl_Position=vec4(0.0,0.0,2.0,1.0);bU=vec2(0.0);bW=vec2(0.0);bZ=vec4(0.0);return;}float aspect=ProjMat[1][1]/ProjMat[0][0];bool front=depth<ai;vec2 ndc=vec2((front?-v.x:v.x)/(az*aspect),v.y/az);float zd=front?(ai-depth):depth;bU=ndc;bW=vec2((front?-v.x:v.x),v.y)/az;bZ=vec4(0.0);gl_Position=vec4(ndc,-1.0+zd*bS,1.0);}else{bX=0.0;bT=0.0;sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);vec4 pos=ProjMat*ModelViewMat*vec4(p,1.0);bU=pos.xy/max(pos.w,1e-6);bW=vec2(0.0);bZ=vec4(0.0);gl_Position=pos;}{vec4 nxc;vec2 nxt=texCoord0;if(cj(Position,Color,ModelViewMat,ProjMat,UV0,nxc,nxt)){vertexColor=nxc;texCoord0=nxt;}}}
