#version 330
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;flat in float bT;flat in float bX;in vec2 bU;in vec2 bW;flat in vec4 bZ;out vec4 fragColor;void main(){vec4 texColor=texture(Sampler0,texCoord0).rrrr;vec4 color=texColor*vertexColor*ColorModulator;if(color.a<0.1)discard;if(bX>0.5){if(bT<-0.5&&(bW.x<bZ.x||bW.x>bZ.y||bW.y<bZ.z||bW.y>bZ.w))discard;fragColor=color;}else{fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}}
