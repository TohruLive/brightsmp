#version 330
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#if !defined(IS_SEE_THROUGH)
flat in float bT;flat in float bX;in vec2 bU;in vec2 bW;flat in vec4 bZ;
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#endif
void main(){
#ifdef IS_GRAYSCALE
vec4 texColor=texture(Sampler0,texCoord0).rrrr;
#else
vec4 texColor=texture(Sampler0,texCoord0);
#endif
#ifdef IS_SEE_THROUGH
vec4 color=texColor*vertexColor;
#else
vec4 color=texColor*vertexColor*ColorModulator;
#endif
if(color.a<0.1)discard;
#if !defined(IS_SEE_THROUGH)
if(bX>0.5){if(bT<-0.5&&(bW.x<bZ.x||bW.x>bZ.y||bW.y<bZ.z||bW.y>bZ.w))discard;}
#endif
#ifdef IS_SEE_THROUGH
fragColor=color*ColorModulator;
#elif defined(IS_GUI)
fragColor=color;
#else
if(bX>0.5){fragColor=color;}else{fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
#endif
}
