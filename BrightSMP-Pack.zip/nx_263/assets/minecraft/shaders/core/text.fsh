#version 330
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#extension GL_ARB_separate_shader_objects : require
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif
#ifdef IS_SEE_THROUGH
#include <minecraft:globals.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
uniform sampler2D Sampler0;layout(location=2)in vec4 vertexColor;layout(location=3)in vec2 texCoord0;
#ifndef OIT_ALPHA_ONLY
layout(location=0)out vec4 fragColor;
#endif
#if !defined(IS_SEE_THROUGH)
layout(location=4)flat in float bT;layout(location=5)flat in float bX;layout(location=6)in vec2 bU;layout(location=7)in vec2 bW;layout(location=8)flat in vec4 bZ;
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location=0)in float sphericalVertexDistance;layout(location=1)in float cylindricalVertexDistance;
#endif
vec4 nxFinalColor(vec4 color){
#ifdef OIT_ACCUMULATE
color=sampleColorForAccumulation(color);
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
if(bX<=0.5){
#ifdef OIT_ACCUMULATE
vec4 fogColor=vec4(FogColor.rgb*color.a,FogColor.a);
#else
vec4 fogColor=FogColor;
#endif
color=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,fogColor);}
#endif
return color;}void main(){
#ifdef IS_SEE_THROUGH
if(GameTime<-0.0001&&GameTime>-0.53333&&!(vertexColor.a*255.0>252.4&&vertexColor.a*255.0<254.6))discard;
#endif
#ifdef IS_GRAYSCALE
vec4 texColor=texture(Sampler0,texCoord0).rrrr;
#else
vec4 texColor=texture(Sampler0,texCoord0);
#endif
vec4 color=texColor*vertexColor*ColorModulator;if(color.a<0.1)discard;
#if !defined(IS_SEE_THROUGH)
if(bX>0.5){if(bT<-0.5&&(bW.x<bZ.x||bW.x>bZ.y||bW.y<bZ.z||bW.y>bZ.w))discard;}
#endif
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z,color.a);
#else
fragColor=nxFinalColor(color);
#endif
}
