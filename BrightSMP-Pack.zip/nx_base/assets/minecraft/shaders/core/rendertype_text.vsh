#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <minecraft:fog.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler0;uniform sampler2D Sampler2;uniform mat4 ModelViewMat;uniform mat4 ProjMat;uniform int FogShape;out float vertexDistance;out vec4 vertexColor;out vec2 texCoord0;flat out float aY;flat out float bb;out vec2 aZ;out vec2 ba;const float aV=110.0;const float C=3.5;const float T=C*tan(radians(aV*0.5));const float B=0.05;const float E=2.0;const float aX=0.004;float _fd(vec3 p,int s){return s==0?length(p):max(length(p.xz),abs(p.y));}uniform float GameTime;
#define A GameTime
#define F 8704.0
#define l 32
#define n 31
#define aA 4
#define aB 3145728
#define aC 6656
#define aD -0.500000000
#define aE 0.000262960180
#define aM 16384.0
#define aK 2072576.0
#define aI 8192.0
#define aL 251
#define aH 254
#define aN 512
#define aJ 249
#define aR 0.100000000
#define aQ 0.0149586227
#define aS -0.0500000000
#define aT -0.100000000
#define aU 0.000293040293
#define aO 0.00140625000
#define aP 0.00250000000
#define aG 3.00000000
#define aF 19.0000000
#define D 182
#define ay 1024
#define az -0.500000000
#define am 2097152
#define ag 2883584
#define ah 512
#define ai 48
#define aq 32
#define ar 8
#define as 4
#define al 16
#define at 2
#define au 4
#define av 5
#define aw 6
#define af 8
#define ax -0.750000000
#define aj 0.0000610550309
#define ak 0.000122100122
#define an 253
#define ao 0.500000000
#define ap 0.00793650794
#define d 1.77777778
#define ae 3
#define W 9
#define X 256.000000
#define aa 240
#define ab 4096.00000
#define ac 2048.00000
#define ad 0.500000000
#define Y 3328.00000
#define Z 0.500000000
#ifndef A
#define A 0.0
#endif
#define f 6000.00000
#define e 1000.00000
#define P 2884608
#define J 7078912
#define H 4194304
#define O 4095.00000
#define L 255
#define R 0.500000000
#define K 32.0000000
#define Q 16.0000000
#define I 0.500000000
#define S 8.00000000
#define M 2.00000000
#define N 1.25000000
#define G 64
#define U 0
#define V 0
#define k 17.777778
#define h 10.000000
#define q 0.2000592966
void bg(int g,float fx,float fy){
#if U || V
bb=1.0;aY=U!=0?float(g):0.0;ba=vec2((fx-0.5)*k,(0.5-fy)*h)*q;
#endif
}void bH(vec4 r,float fx,float fy){
#if V
bb=1.0;aY=-1.0;ba=vec2((fx-0.5)*k,(0.5-fy)*h)*q;bc=vec4((r.x-0.5)*k,(r.z-0.5)*k,(0.5-r.w)*h,(0.5-r.y)*h)*q;
#endif
}int bt(ivec2 c,int dir,int j){vec3 t=texelFetch(Sampler0,c+ivec2(dir*(j/3),0),0).rgb;int m=j-(j/3)*3;float v=m==0?t.r:(m==1?t.g:t.b);return int(v*255.0+0.5);}float bu(ivec2 c,int dir,int o){int u=bt(c,dir,o)+bt(c,dir,o+1)*256+bt(c,dir,o+2)*65536;if(u>=8388608)u-=16777216;return float(u)/65536.0;}vec4 bv(ivec2 c,int dir,int o){return vec4(bu(c,dir,o),bu(c,dir,o+3),bu(c,dir,o+6),bu(c,dir,o+9));}float bs(ivec2 c,int dir,int o){return bu(c,dir,o)*(65536.0/X);}vec2 bd(int a,float gw,float gh){return vec2(float(a-(a/3)*3)*0.5*gw,float(a/3)*0.5*gh);}bool bi(vec3 bF,vec4 bE,mat4 br,mat4 bq,vec2 bG,out vec4 nxColor,inout vec2 bD){nxColor=bE;if(bq[3][3]<0.5)return false;vec3 bj=(br*vec4(bF,1.0)).xyz;float by=abs(2.0/bq[0][0]);float bx=abs(2.0/bq[1][1]);float bm=bj.x-by*0.5-F;bool bp=bm>0.0?(bm>=aM&&bm<aK):(-bm>aM&&-bm<=aK);bool bo=bm<=-float(am)&&bm>-float(ag);bool bn=bm<-float(ag)&&bm>=-float(J);if(!bp&&!bo&&!bn&&bm<float(am))return false;float bw=by/max(bx,1.0e-3);float bA,bz;if(bw>d){bz=bx;bA=bx*d;}else{bA=by;bz=by/d;}float bB=(by-bA)*0.5;float bC=(bx-bz)*0.5;vec2 bh=fract(bG*vec2(textureSize(Sampler0,0)));float bf=bh.x>0.5?1.0:0.0;float be=bh.y>0.5?1.0:0.0;float bl=floor(by+0.5);float bk=floor(bx+0.5);if(bp){int ta=int(bE.a*255.0+0.5);if(ta>=255){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}if(ta<1||ta>aH)return false;float tside=bm>0.0?1.0:-1.0;int tfield=tside>0.0?int(floor((bm-aM)/aI)):int(ceil((-bm-aM)/aI))-1;if(tfield<0||tfield>=aL)return false;float tbase=tside>0.0?aM+float(tfield)*aI:-(aM+float(tfield+1)*aI);int tlook=(ta-1)*2*aL+(tside>0.0?tfield:tfield+aL);int tclip=tlook/aN;if(tclip>=aJ)return false;int tucode=tlook-tclip*aN;int t8r=int(bE.r*255.0+0.5),t8g=int(bE.g*255.0+0.5),t8b=int(bE.b*255.0+0.5);int ty12=t8r*16+(t8g>>4);float tu=aR*exp2(float(tucode)*aQ);ivec2 tts=textureSize(Sampler0,0);vec4 tbk=texelFetch(Sampler0,ivec2(floor(bG*vec2(tts))),0);bool tbaked=tbk.a>0.99&&int(tbk.r*255.0+0.5)==D;float tso=tbaked?1.0:(fract(bj.y)>0.25?0.5:1.0);float tlocal;if(tbaked){float btop=float(int(tbk.g*255.0+0.5)),bcell=float(int(tbk.b*255.0+0.5));tlocal=be>0.5?bcell-btop:-btop;}else{float tyy=bj.y-tso-aG;tlocal=tyy-aF*floor((tyy+6.0)/aF);}nxColor=vec4(float(t8g&15)*17.0,float(t8b>>4)*17.0,float(t8b&15)*17.0,255.0)/255.0;if(tbaked)bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(tts.y));if(tclip>=aa){vec2 tanc=bd(tclip-aa,bl,bk);gl_Position=bq*vec4(tanc.x+(bm-tbase-tso-ab)*tu,tanc.y+(float(ty12)-ac)*ad+tlocal*tu,bj.z,1.0);bg(0,0.5,0.5);return true;}float tfx=aS+(bm-tbase-tso)*tu*aO;float tfy=aT+float(ty12)*aU+tlocal*tu*aP;gl_Position=bq*vec4(bB+tfx*bA,bC+tfy*bz,bj.z,1.0);bg(tclip,tfx,tfy);return true;}if(bn){ivec2 gts=textureSize(Sampler0,0);ivec2 gpc=ivec2(floor(bG*vec2(gts)));int gdir=bf>0.5?-1:1;int gflags=bt(gpc,gdir,0);if((gflags>>4)!=at||(gflags&aA)!=0||(gflags&af)==0)return false;int ga=int(bE.a*255.0+0.5);if(ga<1||ga>G){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int gw=bt(gpc,gdir,14)+bt(gpc,gdir,15)*256;int gcode=-(int(floor(bm+0.5))-(bf>0.5?gw:0)-1)-P;if(gcode<0||gcode>=H){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int gk=gcode/4096;int gv=(ga-1)*16777216+int(bE.r*255.0+0.5)*65536+int(bE.g*255.0+0.5)*256+int(bE.b*255.0+0.5);int gm=gv/4096;int gqn=2*L+1;vec2 gq=vec2(float(gk/2-L),float(gm-(gm/gqn)*gqn-L))/float(L);float ge=mod(A*24000.0-float(gm/gqn)/Q,K);if(ge>=K-S)ge-=K;ge=clamp(ge,-I,(gk-(gk/2)*2)!=0?M:N);vec2 gp=clamp(vec2(float(gcode-gk*4096),float(gv-gm*4096))/O+sign(gq)*gq*gq*R*ge,0.0,1.0);vec4 grc=bv(gpc,gdir,2);float gfx=gp.x+(bf>0.5?grc.z:grc.x);float gfy=gp.y+(be>0.5?grc.w:grc.y);bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(gts.y));gl_Position=bq*vec4(bB+gfx*bA,bC+gfy*bz,bj.z,1.0);float gnear=(bq[2][2]>0.0)?1.0:-1.0;gl_Position.z=gl_Position.w*gnear*0.9999;bg(0,0.5,0.5);nxColor=vec4(1.0);return true;}if(bm>=float(aB)){ivec2 rts=textureSize(Sampler0,0);ivec2 rc=ivec2(floor(bG*vec2(rts)));int rdir=bf>0.5?-1:1;int rflags=bt(rc,rdir,0);bool rovl=(rflags>>4)==ae;if((!rovl&&(rflags>>4)!=at)||(rflags&aA)==0)return false;int rclip=bt(rc,rdir,1);int rgrid=bt(rc,rdir,2);int rrow=bt(rc,rdir,3);if(rgrid<1||rrow>=rgrid||(rovl&&rclip>=W))return false;float rx0=bu(rc,rdir,4),rx1=bu(rc,rdir,7),rh=bu(rc,rdir,10);int rraw=int(floor(bm+0.5))-(bf>0.5?n:0)-aB;if(rraw<0)return false;int ridx=rraw/l;int rlevel=ridx/rgrid;if(rlevel>=aC)return false;int rcol=ridx-rlevel*rgrid;bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(rts.y));nxColor=bE;if(rovl){float rk=65536.0/X;vec2 ranc=bd(rclip,bl,bk);gl_Position=bq*vec4(ranc.x+(rx0+(float(rcol)+bf)*(rx1-rx0)/float(rgrid))*rk,ranc.y+(float(rlevel)-Y)*Z+(float(rrow)+be)*rh*rk/float(rgrid),bj.z,1.0);bg(0,0.5,0.5);return true;}float rfx=rx0+(float(rcol)+bf)*(rx1-rx0)/float(rgrid);float rfy=aD+float(rlevel)*aE+(float(rrow)+be)*rh/float(rgrid);gl_Position=bq*vec4(bB+rfx*bA,bC+rfy*bz,bj.z,1.0);bg(rclip,rfx,rfy);return true;}if(bm<float(ag)){int pq;float pscale=1.0;if(bo){int pa=int(bE.a*255.0+0.5);if(pa<1||pa>an){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}pscale=ao*exp2(float(pa-1)*ap);pq=int(ceil((-bm-float(am))/float(ah)))-1;}else{int praw=int(floor(bm+0.5))-am;pq=praw/ah;}int pfield=pq/aq;int psub=pq-pfield*aq;if(pfield>=ai)return false;ivec2 pts=textureSize(Sampler0,0);ivec2 pc=ivec2(floor(bG*vec2(pts)));int pdir=bf>0.5?-1:1;int pflags=bt(pc,pdir,0);bool povl=(pflags>>4)==ae&&(pflags&aA)==0&&!bo;int pver=pflags>>4;bool pgif=pver==au||pver==aw;bool pwin=pver==av||pver==aw;if(!povl&&((pver!=at&&!pgif&&!pwin)||(pflags&aA)!=0))return false;int p8r=int(bE.r*255.0+0.5),p8g=int(bE.g*255.0+0.5),p8b=int(bE.b*255.0+0.5);int px12=p8r*16+(p8g>>4);if(px12<ay){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(pts.y));if(povl){int pa9=bt(pc,pdir,1);if(pa9>=W)return false;vec2 panc=bd(pa9,bl,bk);gl_Position=bq*vec4(panc.x+bs(pc,pdir,bf>0.5?8:2),panc.y+bs(pc,pdir,be>0.5?11:5),bj.z,1.0);bg(0,0.5,0.5);nxColor=vec4(1.0);return true;}int psx=psub-(psub/ar)*ar;int psy=psub/ar;float pox=az+float((px12-ay)*ar+psx)*aj;float poy=ax+float(((p8g&15)*256+p8b)*as+psy)*ak;int pclip=bt(pc,pdir,1);bool hasH=(pflags&1)!=0,hasC=(pflags&2)!=0;vec4 r=bv(pc,pdir,2);int pstate=pfield/al;float pk=pstate==0?0.0:float(pfield-pstate*al)/float(al-1);if(pstate==1&&hasH)r=mix(r,bv(pc,pdir,14),pk);else if(pstate==2&&hasC)r=mix(hasH?bv(pc,pdir,14):r,bv(pc,pdir,hasH?26:14),pk);else if(pstate==2&&hasH)r=bv(pc,pdir,14);float pfx=pox+pscale*(bf>0.5?r.z:r.x);float pfy=poy+pscale*(be>0.5?r.w:r.y);gl_Position=bq*vec4(bB+pfx*bA,bC+pfy*bz,bj.z,1.0);if((pflags&af)!=0){float cnear=(bq[2][2]>0.0)?1.0:-1.0;gl_Position.z=gl_Position.w*cnear*0.9999;bg(0,0.5,0.5);}else if(pwin){bH(bv(pc,pdir,2+12*(1+(hasH?1:0)+(hasC?1:0))),pfx,pfy);}else{bg(pclip,pfx,pfy);}nxColor=vec4(1.0,1.0,1.0,bo?1.0:bE.a);return true;}return false;}void main(){vec3 p=Position;bool isNxGui=(ProjMat[2][3]!=0.0)&&(UV2.x>=232)&&(abs(Color.a*255.0-254.0)<0.6);if(isNxGui){vertexColor=Color;}else{vertexColor=Color*texelFetch(Sampler2,UV2/16,0);}texCoord0=UV0;if(isNxGui){vertexDistance=0.0;bb=1.0;aY=clamp(15.0-float(UV2.y/16),0.0,15.0);vec4 v=ModelViewMat*vec4(p,1.0);float depth=-v.z;if(depth<B){gl_Position=vec4(0.0,0.0,2.0,1.0);aZ=vec2(0.0);ba=vec2(0.0);return;}float aspect=ProjMat[1][1]/ProjMat[0][0];bool front=depth<E;vec2 ndc=vec2((front?-v.x:v.x)/(T*aspect),v.y/T);float zd=front?(E-depth):depth;aZ=ndc;ba=vec2((front?-v.x:v.x),v.y)/T;gl_Position=vec4(ndc,-1.0+zd*aX,1.0);}else{bb=0.0;aY=0.0;vertexDistance=_fd(p,FogShape);vec4 pos=ProjMat*ModelViewMat*vec4(p,1.0);aZ=pos.xy/max(pos.w,1e-6);ba=vec2(0.0);gl_Position=pos;}{vec4 nxc;vec2 nxt=texCoord0;if(bi(Position,Color,ModelViewMat,ProjMat,UV0,nxc,nxt)){vertexColor=nxc;texCoord0=nxt;}}}
