#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
uniform sampler2D Sampler0;uniform vec4 ColorModulator;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;void main(){vec4 color=texture(Sampler0,texCoord0)*vertexColor;if(color.a<0.1){discard;}fragColor=color*ColorModulator;}
