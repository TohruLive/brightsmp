#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <fog.glsl>
uniform sampler2D Sampler0;uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;in vec4 vertexColor;in vec2 texCoord0;flat in float aY;flat in float bb;in vec2 aZ;in vec2 ba;out vec4 fragColor;void main(){vec4 texColor=texture(Sampler0,texCoord0);vec4 color=texColor*vertexColor*ColorModulator;if(color.a<0.1)discard;if(bb>0.5){fragColor=color;}else{fragColor=linear_fog(color,vertexDistance,FogStart,FogEnd,FogColor);}}
