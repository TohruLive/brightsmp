#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
uniform sampler2D Sampler0;
#define NXM_HAS_Sampler0
uniform vec4 ColorModulator;
#define NXM_HAS_ColorModulator
in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#define NXM_HAS_fragColor
void dK(){vec4 color=texture(Sampler0,texCoord0)*vertexColor*ColorModulator;if(color.a<0.1){discard;}fragColor=color;}
#moj_import <fog.glsl>
#ifndef NXM_HAS_Sampler0
uniform sampler2D Sampler0;
#endif
#ifndef NXM_HAS_ColorModulator
uniform vec4 ColorModulator;
#endif
uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float dN;in vec4 dM;in vec2 dL;flat in float ds;flat in float dz;in vec2 dw;in vec2 dx;
#ifndef NXM_HAS_fragColor
out vec4 fragColor;
#endif
void dI(){vec4 texColor=texture(Sampler0,dL);vec4 color=texColor*dM*ColorModulator;if(color.a<0.1)discard;if(dz>0.5){fragColor=color;}else{fragColor=linear_fog(color,dN,FogStart,FogEnd,FogColor);}}flat in float dq;void dv(){}void main(){if(dq>0.5){dI();}else{dv();dK();}}
