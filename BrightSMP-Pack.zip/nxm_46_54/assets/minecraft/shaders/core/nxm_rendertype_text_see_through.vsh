#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
in vec3 Position;
#define NXM_HAS_Position
in vec4 Color;
#define NXM_HAS_Color
in vec2 UV0;
#define NXM_HAS_UV0
uniform mat4 ModelViewMat;
#define NXM_HAS_ModelViewMat
uniform mat4 ProjMat;
#define NXM_HAS_ProjMat
uniform float GameTime;
#define NXM_HAS_GameTime
out vec4 vertexColor;out vec2 texCoord0;const bool ORAXEN_ANIMATED_GLYPHS=true;const int ORAXEN_ANIM_CONFIG_COUNT=1;const ivec2 ORAXEN_ANIM_CONFIGS[1]=ivec2[](ivec2(16,16));void dK(){vec3 pos=Position;gl_Position=ProjMat*ModelViewMat*vec4(pos,1.0);texCoord0=UV0;vertexColor=Color;int rInt=int(Color.r*255.0+0.5);int gRaw=int(Color.g*255.0+0.5);int bRaw=int(Color.b*255.0+0.5);bool isPrimaryAnim=false;if(ORAXEN_ANIMATED_GLYPHS&&ORAXEN_ANIM_CONFIG_COUNT>0&&rInt==254){int candidateFrameIndex=bRaw&0x0F;int candidateTotalFrames=((bRaw>>4)&0x0F)+1;if(candidateFrameIndex<candidateTotalFrames){for(int i=0;i<ORAXEN_ANIM_CONFIG_COUNT;i++){if(gRaw==ORAXEN_ANIM_CONFIGS[i].x&&candidateTotalFrames==ORAXEN_ANIM_CONFIGS[i].y){isPrimaryAnim=true;break;}}}}if(ORAXEN_ANIMATED_GLYPHS&&isPrimaryAnim){int gInt=gRaw;int bInt=bRaw;bool loop=(gInt<128);float fps=max(1.0,float(gInt&0x7F));int frameIndex=bInt&0x0F;int totalFrames=((bInt>>4)&0x0F)+1;float timeSeconds=(GameTime<=1.0)?(GameTime*1200.0):(GameTime/20.0);int rawFrame=int(floor(timeSeconds*fps));int currentFrame=loop?int(mod(float(rawFrame),float(totalFrames))):min(rawFrame,totalFrames-1);float visible=(frameIndex==currentFrame&&isPrimaryAnim)?1.0:0.0;vertexColor=vec4(1.0,1.0,1.0,visible);}}bool dr=false;
#moj_import <fog.glsl>
#ifndef NXM_HAS_Position
in vec3 Position;
#endif
#ifndef NXM_HAS_Color
in vec4 Color;
#endif
#ifndef NXM_HAS_UV0
in vec2 UV0;
#endif
in ivec2 UV2;uniform sampler2D Sampler0;uniform sampler2D Sampler2;
#ifndef NXM_HAS_ModelViewMat
uniform mat4 ModelViewMat;
#endif
#ifndef NXM_HAS_ProjMat
uniform mat4 ProjMat;
#endif
uniform int FogShape;uniform vec3 ChunkOffset;out float dN;out vec4 dM;out vec2 dL;flat out float ds;flat out float dz;out vec2 dw;out vec2 dx;const float dl=110.0;const float bS=3.5;const float cj=bS*tan(radians(dl*0.5));const float bR=0.05;const float bU=2.0;const float dn=0.004;float dp(vec3 p,int s){return s==0?length(p):max(length(p.xz),abs(p.y));}
#ifndef NXM_HAS_GameTime
uniform float GameTime;
#endif
#define bQ GameTime
#define bV 8704.0
#define bN 32
#define bO 31
#define cQ 4
#define cR 3145728
#define cS 6656
#define cT -0.500000000
#define cU 0.000262960180
#define dc 16384.0
#define da 2072576.0
#define cY 8192.0
#define db 251
#define cX 254
#define dd 512
#define cZ 249
#define dh 0.100000000
#define dg 0.0149586227
#define di -0.0500000000
#define dj -0.100000000
#define dk 0.000293040293
#define de 0.00140625000
#define df 0.00250000000
#define cW 3.00000000
#define cV 19.0000000
#define bT 182
#define cO 1024
#define cP -0.500000000
#define cC 2097152
#define cw 2883584
#define cx 512
#define cy 48
#define cG 32
#define cH 8
#define cI 4
#define cB 16
#define cJ 2
#define cK 4
#define cL 5
#define cM 6
#define cv 8
#define cN -0.750000000
#define cz 0.0000610550309
#define cA 0.000122100122
#define cD 253
#define cE 0.500000000
#define cF 0.00793650794
#define bI 1.77777778
#define cu 3
#define cm 9
#define cn 256.000000
#define cq 240
#define cr 4096.00000
#define cs 2048.00000
#define ct 0.500000000
#define co 3328.00000
#define cp 0.500000000
#ifndef bQ
#define bQ 0.0
#endif
#define bK 6000.00000
#define bJ 1000.00000
#define cf 2884608
#define bZ 7078912
#define bX 4194304
#define ce 4095.00000
#define cb 255
#define ch 0.500000000
#define ca 32.0000000
#define cg 16.0000000
#define bY 0.500000000
#define ci 8.00000000
#define cc 2.00000000
#define cd 1.25000000
#define bW 64
#define ck 0
#define cl 0
#define bM 17.777778
#define bL 10.000000
#define bP 0.2000592966
void dB(int g,float fx,float fy){
#if ck || cl
dz=1.0;ds=ck!=0?float(g):0.0;dx=vec2((fx-0.5)*bM,(0.5-fy)*bL)*bP;
#endif
}void dH(vec4 r,float fx,float fy){
#if cl
dz=1.0;ds=-1.0;dx=vec2((fx-0.5)*bM,(0.5-fy)*bL)*bP;bc=vec4((r.x-0.5)*bM,(r.z-0.5)*bM,(0.5-r.w)*bL,(0.5-r.y)*bL)*bP;
#endif
}int dE(ivec2 c,int dir,int j){vec3 t=texelFetch(Sampler0,c+ivec2(dir*(j/3),0),0).rgb;int m=j-(j/3)*3;float v=m==0?t.r:(m==1?t.g:t.b);return int(v*255.0+0.5);}float dF(ivec2 c,int dir,int o){int u=dE(c,dir,o)+dE(c,dir,o+1)*256+dE(c,dir,o+2)*65536;if(u>=8388608)u-=16777216;return float(u)/65536.0;}vec4 dG(ivec2 c,int dir,int o){return vec4(dF(c,dir,o),dF(c,dir,o+3),dF(c,dir,o+6),dF(c,dir,o+9));}float dD(ivec2 c,int dir,int o){return dF(c,dir,o)*(65536.0/cn);}vec2 dA(int a,float gw,float gh){return vec2(float(a-(a/3)*3)*0.5*gw,float(a/3)*0.5*gh);}bool du(vec3 bF,vec4 bE,mat4 br,mat4 bq,vec2 bG,out vec4 nxColor,inout vec2 bD){nxColor=bE;if(bq[3][3]<0.5)return false;vec3 bj=(br*vec4(bF,1.0)).xyz;float by=abs(2.0/bq[0][0]);float bx=abs(2.0/bq[1][1]);float bm=bj.x-by*0.5-bV;bool bp=bm>0.0?(bm>=dc&&bm<da):(-bm>dc&&-bm<=da);bool bo=bm<=-float(cC)&&bm>-float(cw);bool bn=bm<-float(cw)&&bm>=-float(bZ);if(!bp&&!bo&&!bn&&bm<float(cC))return false;float bw=by/max(bx,1.0e-3);float bA,bz;if(bw>bI){bz=bx;bA=bx*bI;}else{bA=by;bz=by/bI;}float bB=(by-bA)*0.5;float bC=(bx-bz)*0.5;vec2 bh=fract(bG*vec2(textureSize(Sampler0,0)));float bf=bh.x>0.5?1.0:0.0;float be=bh.y>0.5?1.0:0.0;float bl=floor(by+0.5);float bk=floor(bx+0.5);if(bp){int ta=int(bE.a*255.0+0.5);if(ta>=255){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}if(ta<1||ta>cX)return false;float tside=bm>0.0?1.0:-1.0;int tfield=tside>0.0?int(floor((bm-dc)/cY)):int(ceil((-bm-dc)/cY))-1;if(tfield<0||tfield>=db)return false;float tbase=tside>0.0?dc+float(tfield)*cY:-(dc+float(tfield+1)*cY);int tlook=(ta-1)*2*db+(tside>0.0?tfield:tfield+db);int tclip=tlook/dd;if(tclip>=cZ)return false;int tucode=tlook-tclip*dd;int t8r=int(bE.r*255.0+0.5),t8g=int(bE.g*255.0+0.5),t8b=int(bE.b*255.0+0.5);int ty12=t8r*16+(t8g>>4);float tu=dh*exp2(float(tucode)*dg);ivec2 tts=textureSize(Sampler0,0);vec4 tbk=texelFetch(Sampler0,ivec2(floor(bG*vec2(tts))),0);bool tbaked=tbk.a>0.99&&int(tbk.r*255.0+0.5)==bT;float tso=tbaked?1.0:(fract(bj.y)>0.25?0.5:1.0);float tlocal;if(tbaked){float btop=float(int(tbk.g*255.0+0.5)),bcell=float(int(tbk.b*255.0+0.5));tlocal=be>0.5?bcell-btop:-btop;}else{float tyy=bj.y-tso-cW;tlocal=tyy-cV*floor((tyy+6.0)/cV);}nxColor=vec4(float(t8g&15)*17.0,float(t8b>>4)*17.0,float(t8b&15)*17.0,255.0)/255.0;if(tbaked)bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(tts.y));if(tclip>=cq){vec2 tanc=dA(tclip-cq,bl,bk);gl_Position=bq*vec4(tanc.x+(bm-tbase-tso-cr)*tu,tanc.y+(float(ty12)-cs)*ct+tlocal*tu,bj.z,1.0);dB(0,0.5,0.5);return true;}float tfx=di+(bm-tbase-tso)*tu*de;float tfy=dj+float(ty12)*dk+tlocal*tu*df;gl_Position=bq*vec4(bB+tfx*bA,bC+tfy*bz,bj.z,1.0);dB(tclip,tfx,tfy);return true;}if(bn){ivec2 gts=textureSize(Sampler0,0);ivec2 gpc=ivec2(floor(bG*vec2(gts)));int gdir=bf>0.5?-1:1;int gflags=dE(gpc,gdir,0);if((gflags>>4)!=cJ||(gflags&cQ)!=0||(gflags&cv)==0)return false;int ga=int(bE.a*255.0+0.5);if(ga<1||ga>bW){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int gw=dE(gpc,gdir,14)+dE(gpc,gdir,15)*256;int gcode=-(int(floor(bm+0.5))-(bf>0.5?gw:0)-1)-cf;if(gcode<0||gcode>=bX){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}int gk=gcode/4096;int gv=(ga-1)*16777216+int(bE.r*255.0+0.5)*65536+int(bE.g*255.0+0.5)*256+int(bE.b*255.0+0.5);int gm=gv/4096;int gqn=2*cb+1;vec2 gq=vec2(float(gk/2-cb),float(gm-(gm/gqn)*gqn-cb))/float(cb);float ge=mod(bQ*24000.0-float(gm/gqn)/cg,ca);if(ge>=ca-ci)ge-=ca;ge=clamp(ge,-bY,(gk-(gk/2)*2)!=0?cc:cd);vec2 gp=clamp(vec2(float(gcode-gk*4096),float(gv-gm*4096))/ce+sign(gq)*gq*gq*ch*ge,0.0,1.0);vec4 grc=dG(gpc,gdir,2);float gfx=gp.x+(bf>0.5?grc.z:grc.x);float gfy=gp.y+(be>0.5?grc.w:grc.y);bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(gts.y));gl_Position=bq*vec4(bB+gfx*bA,bC+gfy*bz,bj.z,1.0);float gnear=(bq[2][2]>0.0)?1.0:-1.0;gl_Position.z=gl_Position.w*gnear*0.9999;dB(0,0.5,0.5);nxColor=vec4(1.0);return true;}if(bm>=float(cR)){ivec2 rts=textureSize(Sampler0,0);ivec2 rc=ivec2(floor(bG*vec2(rts)));int rdir=bf>0.5?-1:1;int rflags=dE(rc,rdir,0);bool rovl=(rflags>>4)==cu;if((!rovl&&(rflags>>4)!=cJ)||(rflags&cQ)==0)return false;int rclip=dE(rc,rdir,1);int rgrid=dE(rc,rdir,2);int rrow=dE(rc,rdir,3);if(rgrid<1||rrow>=rgrid||(rovl&&rclip>=cm))return false;float rx0=dF(rc,rdir,4),rx1=dF(rc,rdir,7),rh=dF(rc,rdir,10);int rraw=int(floor(bm+0.5))-(bf>0.5?bO:0)-cR;if(rraw<0)return false;int ridx=rraw/bN;int rlevel=ridx/rgrid;if(rlevel>=cS)return false;int rcol=ridx-rlevel*rgrid;bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(rts.y));nxColor=bE;if(rovl){float rk=65536.0/cn;vec2 ranc=dA(rclip,bl,bk);gl_Position=bq*vec4(ranc.x+(rx0+(float(rcol)+bf)*(rx1-rx0)/float(rgrid))*rk,ranc.y+(float(rlevel)-co)*cp+(float(rrow)+be)*rh*rk/float(rgrid),bj.z,1.0);dB(0,0.5,0.5);return true;}float rfx=rx0+(float(rcol)+bf)*(rx1-rx0)/float(rgrid);float rfy=cT+float(rlevel)*cU+(float(rrow)+be)*rh/float(rgrid);gl_Position=bq*vec4(bB+rfx*bA,bC+rfy*bz,bj.z,1.0);dB(rclip,rfx,rfy);return true;}if(bm<float(cw)){int pq;float pscale=1.0;if(bo){int pa=int(bE.a*255.0+0.5);if(pa<1||pa>cD){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}pscale=cE*exp2(float(pa-1)*cF);pq=int(ceil((-bm-float(cC))/float(cx)))-1;}else{int praw=int(floor(bm+0.5))-cC;pq=praw/cx;}int pfield=pq/cG;int psub=pq-pfield*cG;if(pfield>=cy)return false;ivec2 pts=textureSize(Sampler0,0);ivec2 pc=ivec2(floor(bG*vec2(pts)));int pdir=bf>0.5?-1:1;int pflags=dE(pc,pdir,0);bool povl=(pflags>>4)==cu&&(pflags&cQ)==0&&!bo;int pver=pflags>>4;bool pgif=pver==cK||pver==cM;bool pwin=pver==cL||pver==cM;if(!povl&&((pver!=cJ&&!pgif&&!pwin)||(pflags&cQ)!=0))return false;int p8r=int(bE.r*255.0+0.5),p8g=int(bE.g*255.0+0.5),p8b=int(bE.b*255.0+0.5);int px12=p8r*16+(p8g>>4);if(px12<cO){gl_Position=vec4(2.0,2.0,2.0,1.0);return true;}bD=bG+vec2(0.0,(be>0.5?-1.0:1.0)/float(pts.y));if(povl){int pa9=dE(pc,pdir,1);if(pa9>=cm)return false;vec2 panc=dA(pa9,bl,bk);gl_Position=bq*vec4(panc.x+dD(pc,pdir,bf>0.5?8:2),panc.y+dD(pc,pdir,be>0.5?11:5),bj.z,1.0);dB(0,0.5,0.5);nxColor=vec4(1.0);return true;}int psx=psub-(psub/cH)*cH;int psy=psub/cH;float pox=cP+float((px12-cO)*cH+psx)*cz;float poy=cN+float(((p8g&15)*256+p8b)*cI+psy)*cA;int pclip=dE(pc,pdir,1);bool hasH=(pflags&1)!=0,hasC=(pflags&2)!=0;vec4 r=dG(pc,pdir,2);int pstate=pfield/cB;float pk=pstate==0?0.0:float(pfield-pstate*cB)/float(cB-1);if(pstate==1&&hasH)r=mix(r,dG(pc,pdir,14),pk);else if(pstate==2&&hasC)r=mix(hasH?dG(pc,pdir,14):r,dG(pc,pdir,hasH?26:14),pk);else if(pstate==2&&hasH)r=dG(pc,pdir,14);float pfx=pox+pscale*(bf>0.5?r.z:r.x);float pfy=poy+pscale*(be>0.5?r.w:r.y);gl_Position=bq*vec4(bB+pfx*bA,bC+pfy*bz,bj.z,1.0);if((pflags&cv)!=0){float cnear=(bq[2][2]>0.0)?1.0:-1.0;gl_Position.z=gl_Position.w*cnear*0.9999;dB(0,0.5,0.5);}else if(pwin){dH(dG(pc,pdir,2+12*(1+(hasH?1:0)+(hasC?1:0))),pfx,pfy);}else{dB(pclip,pfx,pfy);}nxColor=vec4(1.0,1.0,1.0,bo?1.0:bE.a);return true;}return false;}bool dC(vec3 bF,vec4 bE,mat4 br,mat4 bq,vec2 bG,out vec4 nxColor,inout vec2 bD){bool r=du(bF,bE,br,bq,bG,nxColor,bD);if(r)dr=true;return r;}void dI(){vec3 p=Position+ChunkOffset;bool isNxGui=(ProjMat[2][3]!=0.0)&&(UV2.x>=232)&&(abs(Color.a*255.0-254.0)<0.6);if(isNxGui){dM=Color;}else{dM=Color*texelFetch(Sampler2,UV2/16,0);}dL=UV0;if(isNxGui){dz=1.0;dN=0.0;ds=clamp(15.0-float(UV2.y/16),0.0,15.0);vec4 v=ModelViewMat*vec4(p,1.0);float depth=-v.z;if(depth<bR){gl_Position=vec4(0.0,0.0,2.0,1.0);dw=vec2(0.0);dx=vec2(0.0);return;}float aspect=ProjMat[1][1]/ProjMat[0][0];bool front=depth<bU;vec2 ndc=vec2((front?-v.x:v.x)/(cj*aspect),v.y/cj);float zd=front?(bU-depth):depth;dw=ndc;dx=vec2((front?-v.x:v.x),v.y)/cj;gl_Position=vec4(ndc,-1.0+zd*dn,1.0);}else{dz=0.0;ds=0.0;dN=dp(p,FogShape);vec4 pos=ProjMat*ModelViewMat*vec4(p,1.0);dw=pos.xy/max(pos.w,1e-6);dx=vec2(0.0);gl_Position=pos;}{vec4 nxc;vec2 nxt=dL;if(dC(Position,Color,ModelViewMat,ProjMat,UV0,nxc,nxt)){dM=nxc;dL=nxt;}}}flat out float dq;void main(){dr=false;dI();if(dz>0.5)dr=true;dq=dr?1.0:0.0;if(!dr)dK();}
