#version 150
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <minecraft:fog.glsl>
uniform sampler2D Sampler0;
#define NXM_HAS_Sampler0
uniform vec4 ColorModulator;
#define NXM_HAS_ColorModulator
uniform float FogStart;
#define NXM_HAS_FogStart
uniform float FogEnd;
#define NXM_HAS_FogEnd
uniform vec4 FogColor;
#define NXM_HAS_FogColor
in float vertexDistance;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#define NXM_HAS_fragColor
void dK(){vec4 color=texture(Sampler0,texCoord0)*vertexColor*ColorModulator;if(color.a<0.1){discard;}fragColor=linear_fog(color,vertexDistance,FogStart,FogEnd,FogColor);}
#moj_import <minecraft:fog.glsl>
#ifndef NXM_HAS_Sampler0
uniform sampler2D Sampler0;
#endif
#ifndef NXM_HAS_ColorModulator
uniform vec4 ColorModulator;
#endif
#ifndef NXM_HAS_FogStart
uniform float FogStart;
#endif
#ifndef NXM_HAS_FogEnd
uniform float FogEnd;
#endif
#ifndef NXM_HAS_FogColor
uniform vec4 FogColor;
#endif
in float dN;in vec4 dM;in vec2 dL;flat in float ds;flat in float dz;in vec2 dw;in vec2 dx;
#ifndef NXM_HAS_fragColor
out vec4 fragColor;
#endif
void dI(){vec4 texColor=texture(Sampler0,dL);vec4 color=texColor*dM*ColorModulator;if(color.a<0.1)discard;if(dz>0.5){fragColor=color;}else{fragColor=linear_fog(color,dN,FogStart,FogEnd,FogColor);}}flat in float dq;void dv(){}void main(){if(dq>0.5){dI();}else{dv();dK();}}
