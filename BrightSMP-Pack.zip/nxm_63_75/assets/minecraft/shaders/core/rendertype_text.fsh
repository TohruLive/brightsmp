#version 330
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;
#define NXM_HAS_Sampler0
in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#define NXM_HAS_fragColor
void dK(){vec4 color=texture(Sampler0,texCoord0)*vertexColor*ColorModulator;if(color.a<0.1){discard;}fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#ifndef NXM_HAS_Sampler0
uniform sampler2D Sampler0;
#endif
in float dJ;in float dt;in vec4 dM;in vec2 dL;flat in float ds;flat in float dz;in vec2 dw;in vec2 dx;
#ifndef NXM_HAS_fragColor
out vec4 fragColor;
#endif
void dI(){vec4 texColor=texture(Sampler0,dL);vec4 color=texColor*dM*ColorModulator;if(color.a<0.1)discard;if(dz>0.5){fragColor=color;}else{fragColor=apply_fog(color,dJ,dt,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}}flat in float dq;void dv(){}void main(){if(dq>0.5){dI();}else{dv();dK();}}
