#version 330
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;
#define NXM_HAS_Sampler0
in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#define NXM_HAS_fragColor
vec4 oraxen_sample_text(){vec4 texel=texture(Sampler0,texCoord0);
#ifdef IS_GRAYSCALE
return texel.rrrr;
#else
return texel;
#endif
}void dK(){vec4 color=oraxen_sample_text()*vertexColor*ColorModulator;if(color.a<0.1){discard;}
#if defined(IS_SEE_THROUGH) || defined(IS_GUI)
fragColor=color;
#else
fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);
#endif
}
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
#ifndef NXM_HAS_Sampler0
uniform sampler2D Sampler0;
#endif
in vec4 dM;in vec2 dL;
#ifndef NXM_HAS_fragColor
out vec4 fragColor;
#endif
#if !defined(IS_SEE_THROUGH)
flat in float ds;flat in float dz;in vec2 dw;in vec2 dx;
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float dJ;in float dt;
#endif
void dI(){
#ifdef IS_GRAYSCALE
vec4 texColor=texture(Sampler0,dL).rrrr;
#else
vec4 texColor=texture(Sampler0,dL);
#endif
#ifdef IS_SEE_THROUGH
vec4 color=texColor*dM;
#else
vec4 color=texColor*dM*ColorModulator;
#endif
if(color.a<0.1)discard;
#if !defined(IS_SEE_THROUGH)
if(dz>0.5){}
#endif
#ifdef IS_SEE_THROUGH
fragColor=color*ColorModulator;
#elif defined(IS_GUI)
fragColor=color;
#else
if(dz>0.5){fragColor=color;}else{fragColor=apply_fog(color,dJ,dt,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
#endif
}flat in float dq;void dv(){}void main(){if(dq>0.5){dI();}else{dv();dK();}}
