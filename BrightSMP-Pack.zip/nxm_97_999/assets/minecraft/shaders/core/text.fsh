#version 330
// NxGui - proprietary. Licensed for use with the NxGui plugin only. Copying, modification and reverse engineering are prohibited.
#extension GL_ARB_separate_shader_objects : require
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#define NXM_INC_assets_minecraft_shaders_include_fog_glsl
#endif
#include <minecraft:dynamictransforms.glsl>
#define NXM_INC_assets_minecraft_shaders_include_dynamictransforms_glsl
#include <minecraft:oit.glsl>
#define NXM_INC_assets_minecraft_shaders_include_oit_glsl
uniform sampler2D Sampler0;
#define NXM_HAS_Sampler0
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location=0)in float sphericalVertexDistance;layout(location=1)in float cylindricalVertexDistance;
#endif
layout(location=2)in vec4 vertexColor;layout(location=3)in vec2 texCoord0;
#ifndef OIT_ALPHA_ONLY
layout(location=0)out vec4 fragColor;
#define NXM_HAS_fragColor
#endif
vec4 calculateFinalColor(vec4 color){
#ifdef OIT_ACCUMULATE
color=sampleColorForAccumulation(color);
#endif
#if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#ifdef OIT_ACCUMULATE
vec4 fogColor=vec4(FogColor.rgb*color.a,FogColor.a);
#else
vec4 fogColor=FogColor;
#endif
color=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,fogColor);
#endif
return color;}void dK(){
#ifdef IS_GRAYSCALE
vec4 texColor=texture(Sampler0,texCoord0).rrrr;
#else
vec4 texColor=texture(Sampler0,texCoord0);
#endif
vec4 color=texColor*vertexColor*ColorModulator;if(color.a<0.1){discard;}
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z,color.a);
#else
fragColor=calculateFinalColor(color);
#endif
}
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#ifndef NXM_INC_assets_minecraft_shaders_include_fog_glsl
#include <minecraft:fog.glsl>
#endif
#endif
#ifdef IS_SEE_THROUGH
#include <minecraft:globals.glsl>
#endif
#ifndef NXM_INC_assets_minecraft_shaders_include_dynamictransforms_glsl
#include <minecraft:dynamictransforms.glsl>
#endif
#ifndef NXM_INC_assets_minecraft_shaders_include_oit_glsl
#include <minecraft:oit.glsl>
#endif
#ifndef NXM_HAS_Sampler0
uniform sampler2D Sampler0;
#endif
layout(location=6)in vec4 dM;layout(location=7)in vec2 dL;
#ifndef OIT_ALPHA_ONLY
#ifndef NXM_HAS_fragColor
layout(location=0)out vec4 fragColor;
#endif
#endif
#if !defined(IS_SEE_THROUGH)
layout(location=8)flat in float ds;layout(location=9)flat in float dz;layout(location=10)in vec2 dw;layout(location=11)in vec2 dx;
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location=4)in float dJ;layout(location=5)in float dt;
#endif
vec4 dy(vec4 color){
#ifdef OIT_ACCUMULATE
color=sampleColorForAccumulation(color);
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
if(dz<=0.5){
#ifdef OIT_ACCUMULATE
vec4 fogColor=vec4(FogColor.rgb*color.a,FogColor.a);
#else
vec4 fogColor=FogColor;
#endif
color=apply_fog(color,dJ,dt,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,fogColor);}
#endif
return color;}void dI(){
#ifdef IS_SEE_THROUGH
if(GameTime<-0.0001&&GameTime>-0.53333&&!(dM.a*255.0>252.4&&dM.a*255.0<254.6))discard;
#endif
#ifdef IS_GRAYSCALE
vec4 texColor=texture(Sampler0,dL).rrrr;
#else
vec4 texColor=texture(Sampler0,dL);
#endif
vec4 color=texColor*dM*ColorModulator;if(color.a<0.1)discard;
#if !defined(IS_SEE_THROUGH)
if(dz>0.5){}
#endif
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z,color.a);
#else
fragColor=dy(color);
#endif
}layout(location=12)flat in float dq;void dv(){
#ifdef IS_SEE_THROUGH
if(GameTime<-0.0001&&GameTime>-0.53333&&!(dM.a*255.0>252.4&&dM.a*255.0<254.6))discard;
#endif
}void main(){if(dq>0.5){dI();}else{dv();dK();}}
